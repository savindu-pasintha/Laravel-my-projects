<?php

namespace App\Exceptions;

class ThrottleException extends \Exception
{
}
