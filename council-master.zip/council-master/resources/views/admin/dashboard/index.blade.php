@extends('admin.layout.app')

@section('administration-content')
    <p>You are on the administration dashboard.</p>
@endsection
