@extends('layouts.app')

@section('content')
    <div class="my-10"><h1>Leaderboard</h1></div>
    <leaderboard></leaderboard>
@endsection
