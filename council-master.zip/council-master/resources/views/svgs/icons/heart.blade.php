<svg xmlns="http://www.w3.org/2000/svg" width="20" height="19" viewBox="0 0 20 19" class="fill-current {{ $class ?? '' }}">
    <g fill="none" fill-rule="evenodd">
        <path d="M-2-3h24v24H-2z"/>
        <path fill="#00DF8F" d="M14.5 0c-1.74 0-3.41.81-4.5 2.09C8.91.81 7.24 0 5.5 0 2.42 0 0 2.42 0 5.5c0 3.78 3.4 6.86 8.55 11.54L10 18.35l1.45-1.32C16.6 12.36 20 9.28 20 5.5 20 2.42 17.58 0 14.5 0z"/>
    </g>
</svg>
