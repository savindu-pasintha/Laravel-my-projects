<span class="mr-3 w-4 h-4 text-grey-dark font-bold border-t-2 border-grey">
	<div class="self-center">LB</div>
</span>