---
name: "\U0001F680 Feature Request"
about: Suggest an idea or improvement for this project
title: ''
labels: ''
assignees: ''

---

**Description**
A clear and concise description of the new feature or improvement.

**Example**
A simple example of the new feature in action. If the new feature changes an existing feature, include a simple before/after comparison.
