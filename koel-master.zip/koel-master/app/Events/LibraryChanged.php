<?php

namespace App\Events;

class LibraryChanged extends Event
{
}
