<?php

namespace App\Events;

class MediaCacheObsolete extends Event
{
}
