<?php

namespace App\Exceptions;

use Exception;

class MediaPathNotSetException extends Exception
{
}
