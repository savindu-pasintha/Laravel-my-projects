<?php

namespace App\Http\Requests\API;

use App\Models\Song;

/**
 * @property Song $song
 */
class SongLikeRequest extends Request
{
}
