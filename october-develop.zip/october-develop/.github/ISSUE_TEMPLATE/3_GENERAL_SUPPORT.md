---
name: "⚠️ General Support"
about: 'This repository is only for reporting bugs or problems. If you need help using OctoberCMS, see: https://octobercms.com/support'
---

This repository is only for reporting bugs or problems. If you need support, please use the following options:

- Forum: https://octobercms.com/forum
- Slack: https://octobercms.slack.com (Get an invite: https://octobercms-slack.herokuapp.com/)
- Stack Overflow: https://stackoverflow.com/questions/tagged/octobercms

Thanks!